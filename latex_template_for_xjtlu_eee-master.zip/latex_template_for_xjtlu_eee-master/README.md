# A LaTeX Template For XJTLU EEE Students
详情请参阅：

http://blog.feieee.com/archives/318

http://blog.feieee.com/archives/340
